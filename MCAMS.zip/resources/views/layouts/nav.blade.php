<nav class="navbar navbar-dark navbar-theme-primary px-4 col-12 d-md-none" style="box-shadow: 2px 2px 10px gray;">
    <a class="navbar-brand me-lg-5 fs-5" href="/dashboard">
        MCAMS
    </a>
    <div class="d-flex align-items-center">
        <button class="navbar-toggler d-md-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
    </div>
</nav>