$.ajaxSetup({
    headers: {  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') }
});

const SweetAlert = Swal.mixin({
    customClass: {
        confirmButton: 'btn btn-primary',
        cancelButton: 'btn btn-gray'
    },
    buttonsStyling: false
});

//BARANGAY ACCOUNT

$(document).on("click", '#create-barangay-account', function(){
    $('#create-barangay-account-modal').modal('show');
});

$(document).on('submit', "#create-barangay-account", function(e){
    e.preventDefault();
    $.ajax({
        type: 'POST',
        url: '/create/barangay-account',
        data: new FormData(this),
        dataType: 'json',
        contentType: false,
        cache: false,
        processData:false,
        beforeSend:function(){
            $('#processing-account').show(50);
            $('#processing-account').html('Processing...');
        },
        success: function(response)
        {
            if(response.Error == 0) {
                $('#processing-account').hide(50);
                SweetAlert.fire({
                    icon: 'success',
                    title: 'Done',
                    text: response.Message,
                    confirmButtonColor: "#3a57e8"
                }).then(function(){ 
                    location.reload();
                    });
            }
        }
    })
});

$(document).on("click", '#edit-barangay-account', function(){

    var userid = $(this).parents('tr').find('td[userid]').attr("userid");
    var firstname = $(this).parents('tr').find('td[firstname]').attr("firstname");
    var lastname = $(this).parents('tr').find('td[lastname]').attr("lastname");
    var email = $(this).parents('tr').find('td[email]').attr("email");
    var contactnumber = $(this).parents('tr').find('td[contactnumber]').attr("contactnumber");
    var address = $(this).parents('tr').find('td[address]').attr("address");

    $("#edit-address option").filter((i, e) => {
        return e.innerHTML.indexOf(address) > -1;
    }).val();

    $('#edit-barangay-userid').val(userid);
    $('#edit-barangay-firstname').val(firstname);
    $('#edit-barangay-lastname').val(lastname);
    $('#edit-barangay-email').val(email);
    $('#edit-barangay-contactnumber').val(contactnumber);
    $('#edit-barangay-address').val(address);

    $('#edit-barangay-account-modal').modal('show');
});

$(document).on('submit', "#update-barangay-account", function(e){
    e.preventDefault();
    $.ajax({
        type: 'POST',
        url: '/update/barangay-account',
        data: new FormData(this),
        dataType: 'json',
        contentType: false,
        cache: false,
        processData:false,
        beforeSend:function(){
            $('#edit-barangay-processing-account').show(50);
            $('#edit-barangay-processing-account').html('Processing...');
        },
        success: function(response)
        {
            if(response.Error == 0) {
                $('#edit-barangay-processing-account').hide(50);
                SweetAlert.fire({
                    icon: 'success',
                    title: 'Done',
                    text: response.Message,
                    confirmButtonColor: "#3a57e8"
                }).then(function(){ 
                    location.reload();
                    });
            }
        }
    })
});

$(document).on("click", "#delete-barangay-account", function(e){

    var userid = $(this).parents('tr').find('td[userid]').attr("userid");

    SweetAlert.fire({
        icon: 'question',
        title: 'Are you sure?',
        text: "This will delete the account permanently.",
        showCancelButton: true,
        confirmButtonColor: '#160e45',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Delete it!'
    }).then((result) => {
        if (result.value) {
            $.ajax({
                type: 'POST',
                url: '/delete/barangay-account',
                data: {userid},
                dataType: 'json',
                cache: false,
                beforeSend:function(){
                    Swal.fire({
                        position: 'center',
                        icon: 'info',
                        title: 'Deleting...',
                        showConfirmButton: false
                    })
                },
                success:function(response){
                    if (response.Error == 0){
                        SweetAlert.fire({
                            icon: 'success',
                            title: 'Done',
                            text: response.Message,
                            confirmButtonColor: "#3a57e8"
                        }).then(function(){ 
                            location.reload();
                            });
                    }
                }
            });
        }
    })
});

//USER ACCOUNT

$(document).on("click", '#edit-user-account', function(){

    var userid = $(this).parents('tr').find('td[userid]').attr("userid");
    var firstname = $(this).parents('tr').find('td[firstname]').attr("firstname");
    var lastname = $(this).parents('tr').find('td[lastname]').attr("lastname");
    var email = $(this).parents('tr').find('td[email]').attr("email");
    var contactnumber = $(this).parents('tr').find('td[contactnumber]').attr("contactnumber");
    var address = $(this).parents('tr').find('td[address]').attr("address");

    $("#edit-address option").filter((i, e) => {
        return e.innerHTML.indexOf(address) > -1;
    }).val();

    $('#edit-user-userid').val(userid);
    $('#edit-user-firstname').val(firstname);
    $('#edit-user-lastname').val(lastname);
    $('#edit-user-email').val(email);
    $('#edit-user-contactnumber').val(contactnumber);
    $('#edit-user-address').val(address);

    $('#edit-user-account-modal').modal('show');
});

$(document).on('submit', "#update-user-account", function(e){
    e.preventDefault();
    $.ajax({
        type: 'POST',
        url: '/update/user-account',
        data: new FormData(this),
        dataType: 'json',
        contentType: false,
        cache: false,
        processData:false,
        beforeSend:function(){
            $('#edit-user-processing-account').show(50);
            $('#edit-user-processing-account').html('Processing...');
        },
        success: function(response)
        {
            if(response.Error == 0) {
                $('#edit-user-account').hide(50);
                SweetAlert.fire({
                    icon: 'success',
                    title: 'Done',
                    text: response.Message,
                    confirmButtonColor: "#3a57e8"
                }).then(function(){ 
                    location.reload();
                    });
            }
        }
    })
});

$(document).on("click", "#delete-user-account", function(e){

    var userid = $(this).parents('tr').find('td[userid]').attr("userid");

    SweetAlert.fire({
        icon: 'question',
        title: 'Are you sure?',
        text: "This will delete the account permanently.",
        showCancelButton: true,
        confirmButtonColor: '#160e45',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Delete it!'
    }).then((result) => {
        if (result.value) {
            $.ajax({
                type: 'POST',
                url: '/delete/user-account',
                data: {userid},
                dataType: 'json',
                cache: false,
                beforeSend:function(){
                    Swal.fire({
                        position: 'center',
                        icon: 'info',
                        title: 'Deleting...',
                        showConfirmButton: false
                    })
                },
                success:function(response){
                    if (response.Error == 0){
                        SweetAlert.fire({
                            icon: 'success',
                            title: 'Done',
                            text: response.Message,
                            confirmButtonColor: "#3a57e8"
                        }).then(function(){ 
                            location.reload();
                            });
                    }
                }
            });
        }
    })
});

$(document).on("click", "#verify-user-account", function(e){

    var userid = $(this).parents('tr').find('td[userid]').attr("userid");

    SweetAlert.fire({
        icon: 'question',
        title: 'Are you sure?',
        text: "Notice: The user account will then be verified. Once validated, the user can utilize the MCAMS to report accidents or crimes in their neighborhood or barangay.",
        showCancelButton: true,
        confirmButtonColor: '#160e45',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Verify!'
    }).then((result) => {
        if (result.value) {
            $.ajax({
                type: 'POST',
                url: '/update/verify-account',
                data: {userid},
                dataType: 'json',
                cache: false,
                beforeSend:function(){
                    Swal.fire({
                        position: 'center',
                        icon: 'info',
                        title: 'Verifying...',
                        showConfirmButton: false
                    })
                },
                success:function(response){
                    if (response.Error == 0){
                        SweetAlert.fire({
                            icon: 'success',
                            title: 'Done',
                            text: response.Message,
                            confirmButtonColor: "#3a57e8"
                        }).then(function(){ 
                            location.reload();
                            });
                    }
                }
            });
        }
    })
});

//USER LIST

$(document).on('change', "#change-type", function(e){
    var type = $('#change-type').val();
    $.ajax({
        type: 'POST',
        url: '/read/user-list',
        data: { type },
        dataType: 'json',
        success: function()
        {
            location.reload();
        }
    })
});

//REPORTS

$(document).on("click", '#create-report', function(){
    $('#create-report-modal').modal('show');
});

$(document).on("click", '#view-photo', function(){

    var photoid = $(this).parents('tr').find('td[photoid]').attr("photoid");

    $('#view-photo-modal-' + photoid).modal('show');
});

function viewPhoto(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#photo-evidence')
                .attr('src', e.target.result)
                .width(250)
                .height(auto);
        };
        reader.readAsDataURL(input.files[0]);
    }
}

$(document).on("change", '#select-type', function(){
    var value = $("#select-type").val();

    if(value == 'Accident') {
        $(".select-accident").show(200);
        $(".select-crime").hide(200);
    }
    if(value == 'Crime/Scandal') {
        $(".select-accident").hide(200);
        $(".select-crime").show(200);
    }
});

$(document).on('submit', "#create-report", function(e){
    e.preventDefault();

    $.ajax({
        type: 'POST',
        url: '/create/report',
        data: new FormData(this),
        dataType: 'json',
        contentType: false,
        cache: false,
        processData:false,
        beforeSend:function(){
            $('#processing-report').show(50);
            $('#processing-report').html('Processing...');
        },
        success: function(response)
        {
            if(response.Error == 0) {
                $('#processing-report').hide(50);
                SweetAlert.fire({
                    icon: 'success',
                    title: 'Done',
                    text: response.Message,
                    confirmButtonColor: "#3a57e8"
                }).then(function(){ 
                    location.reload();
                    });
            }
        }
    })
});

$(document).on("click", '#edit-report', function(){

    var reportid = $(this).parents('tr').find('td[reportid]').attr("reportid");
    var description = $(this).parents('tr').find('td[description]').attr("description");
    var type = $(this).parents('tr').find('td[type]').attr("type");
    var subtype = $(this).parents('tr').find('td[subtype]').attr("subtype");
    var location = $(this).parents('tr').find('td[location]').attr("location");
    var zone = $(this).parents('tr').find('td[zone]').attr("zone");

    if(type == "Accident") {
        $(".edit-accident").show(100);
        $(".edit-crime").hide(100);

        $("#edit-accident-select option").filter((i, e) => {
         return e.innerHTML.indexOf(subtype) > -1;
        }).val();

        $('#edit-accident-select').val(subtype);
    }
    if(type == "Crime/Scandal") {
        $(".edit-crime").show(100);
        $(".edit-accident").hide(100);

        $("#edit-crime-select option").filter((i, e) => {
            return e.innerHTML.indexOf(subtype) > -1;
        }).val();

        $('#edit-crime-select').val(subtype);
    }

    $("#edit-type option").filter((i, e) => {
        return e.innerHTML.indexOf(type) > -1;
    }).val();

    $("#edit-location option").filter((i, e) => {
        return e.innerHTML.indexOf(location) > -1;
    }).val();

    $('#edit-reportid').val(reportid);
    $('#edit-description').val(description);
    $('#edit-type').val(type);
    $('#edit-location').val(location);
    $('#edit-zone').val(zone);
    $('#edit-report-modal').modal('show');
});

$(document).on("change", '#edit-type', function(){
    var value = $("#edit-type").val();

    if(value == 'Accident') {
        $(".edit-accident").show(200);
        $(".edit-crime").hide(200);
    }
    if(value == 'Crime/Scandal') {
        $(".edit-accident").hide(200);
        $(".edit-crime").show(200);
    }
});

$(document).on('submit', "#update-report", function(e){
    e.preventDefault();
    $.ajax({
        type: 'POST',
        url: '/update/report',
        data: new FormData(this),
        dataType: 'json',
        contentType: false,
        cache: false,
        processData:false,
        beforeSend:function(){
            $('#edit-processing-report').show(50);
            $('#edit-processing-report').html('Processing...');
        },
        success: function(response)
        {
            if(response.Error == 0) {
                $('#dit-processing-report').hide(50);
                SweetAlert.fire({
                    icon: 'success',
                    title: 'Done',
                    text: response.Message,
                    confirmButtonColor: "#3a57e8"
                }).then(function(){ 
                    location.reload();
                    });
            }
        }
    })
});

$(document).on("click", "#delete-report", function(e){

    var reportid = $(this).parents('tr').find('td[reportid]').attr("reportid");

    SweetAlert.fire({
        icon: 'question',
        title: 'Are you sure?',
        text: "This will delete the report permanently.",
        showCancelButton: true,
        confirmButtonColor: '#160e45',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Delete it!'
    }).then((result) => {
        if (result.value) {
            $.ajax({
                type: 'POST',
                url: '/delete/report',
                data: {reportid},
                dataType: 'json',
                cache: false,
                beforeSend:function(){
                    Swal.fire({
                        position: 'center',
                        icon: 'info',
                        title: 'Deleting...',
                        showConfirmButton: false
                    })
                },
                success:function(response){
                    if (response.Error == 0){
                        SweetAlert.fire({
                            icon: 'success',
                            title: 'Done',
                            text: response.Message,
                            confirmButtonColor: "#3a57e8"
                        }).then(function(){ 
                            location.reload();
                            });
                    }
                }
            });
        }
    })
});

//ACCIDENT REPORTS:

$(document).on("click", "#accident-report-respond", function(e){

    var reportid = $(this).parents('tr').find('td[reportid]').attr("reportid");

    SweetAlert.fire({
        icon: 'question',
        title: 'Are you sure?',
        text: "This will confirm that the accident/case has already been solved.",
        showCancelButton: true,
        confirmButtonColor: '#160e45',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Confirm!'
    }).then((result) => {
        if (result.value) {
            $.ajax({
                type: 'POST',
                url: '/update/accident-report-respond',
                data: {reportid},
                dataType: 'json',
                cache: false,
                beforeSend:function(){
                    Swal.fire({
                        position: 'center',
                        icon: 'info',
                        title: 'Responding...',
                        showConfirmButton: false
                    })
                },
                success:function(response){
                    if (response.Error == 0){
                        SweetAlert.fire({
                            icon: 'success',
                            title: 'Done',
                            text: response.Message,
                            confirmButtonColor: "#3a57e8"
                        }).then(function(){ 
                            location.reload();
                            });
                    }
                }
            });
        }
    })
});

$(document).on("click", "#accident-report-police", function(e){

    var reportid = $(this).parents('tr').find('td[reportid]').attr("reportid");

    SweetAlert.fire({
        icon: 'question',
        title: 'Are you sure?',
        text: "This will be reported to the police station.",
        showCancelButton: true,
        confirmButtonColor: '#160e45',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Report!'
    }).then((result) => {
        if (result.value) {
            $.ajax({
                type: 'POST',
                url: '/update/accident-report-police',
                data: {reportid},
                dataType: 'json',
                cache: false,
                beforeSend:function(){
                    Swal.fire({
                        position: 'center',
                        icon: 'info',
                        title: 'Reporting...',
                        showConfirmButton: false
                    })
                },
                success:function(response){
                    if (response.Error == 0){
                        SweetAlert.fire({
                            icon: 'success',
                            title: 'Done',
                            text: response.Message,
                            confirmButtonColor: "#3a57e8"
                        }).then(function(){ 
                            location.reload();
                            });
                    }
                }
            });
        }
    })
});

//CRIME REPORTS

$(document).on("click", "#crime-report-respond", function(e){

    var reportid = $(this).parents('tr').find('td[reportid]').attr("reportid");

    SweetAlert.fire({
        icon: 'question',
        title: 'Are you sure?',
        text: "This will confirm that the accident/case has already been solved.",
        showCancelButton: true,
        confirmButtonColor: '#160e45',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Confirm!'
    }).then((result) => {
        if (result.value) {
            $.ajax({
                type: 'POST',
                url: '/update/crime-report-respond',
                data: {reportid},
                dataType: 'json',
                cache: false,
                beforeSend:function(){
                    Swal.fire({
                        position: 'center',
                        icon: 'info',
                        title: 'Responding...',
                        showConfirmButton: false
                    })
                },
                success:function(response){
                    if (response.Error == 0){
                        SweetAlert.fire({
                            icon: 'success',
                            title: 'Done',
                            text: response.Message,
                            confirmButtonColor: "#3a57e8"
                        }).then(function(){ 
                            location.reload();
                            });
                    }
                }
            });
        }
    })
});

$(document).on("click", "#crime-report-police", function(e){

    var reportid = $(this).parents('tr').find('td[reportid]').attr("reportid");

    SweetAlert.fire({
        icon: 'question',
        title: 'Are you sure?',
        text: "This will be reported to the police station.",
        showCancelButton: true,
        confirmButtonColor: '#160e45',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Report!'
    }).then((result) => {
        if (result.value) {
            $.ajax({
                type: 'POST',
                url: '/update/crime-report-police',
                data: {reportid},
                dataType: 'json',
                cache: false,
                beforeSend:function(){
                    Swal.fire({
                        position: 'center',
                        icon: 'info',
                        title: 'Reporting...',
                        showConfirmButton: false
                    })
                },
                success:function(response){
                    if (response.Error == 0){
                        SweetAlert.fire({
                            icon: 'success',
                            title: 'Done',
                            text: response.Message,
                            confirmButtonColor: "#3a57e8"
                        }).then(function(){ 
                            location.reload();
                            });
                    }
                }
            });
        }
    })
});

//PROFILE UPDATE

$(document).on("submit", "#update-profile", function(e){

    e.preventDefault();

    SweetAlert.fire({
        icon: 'question',
        title: 'Are you sure?',
        text: "Your account information will be updated.",
        showCancelButton: true,
        confirmButtonColor: '#160e45',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Update!'
    }).then((result) => {
        if (result.value) {
            $.ajax({
                type: 'POST',
                url: '/update/profile',
                data: new FormData(this),
                dataType: 'json',
                contentType: false,
                cache: false,
                processData:false,
                beforeSend:function(){
                    Swal.fire({
                        position: 'center',
                        icon: 'info',
                        title: 'Updating...',
                        showConfirmButton: false
                    })
                },
                success:function(response){

                    if (response.Error == 0){
                        SweetAlert.fire({
                            icon: 'success',
                            title: 'Done',
                            text: response.Message,
                            confirmButtonColor: "#3a57e8"
                        }).then(function(){ 
                            location.reload();
                            });
                    }

                    if (response.Error == 1){
                        SweetAlert.fire({
                            icon: 'error',
                            title: 'Update Failed',
                            text: response.Message,
                            confirmButtonColor: "#3a57e8"
                        });
                    }
                }
            });
        }
    })
});

//NOT VERIFIED

$(document).on("click", "#not-verified", function(e){

    $('#errorEffect')[0].play();

    SweetAlert.fire({
        icon: 'warning',
        title: 'Account is under review',
        text: "Sorry, you are not authorized to access this page.",
        confirmButtonColor: '#160e45',
        confirmButtonText: 'Okay'
    })
});

//UPDATE PROFILE PHOTO

$(document).on("click", '#update-profile-photo', function(){
    $('#update-profile-photo-modal').modal('show');
});

function viewProfilePhoto(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#profile-photo')
                .attr('src', e.target.result)
                .width(200)
                .height(auto);
        };
        reader.readAsDataURL(input.files[0]);
    }
}

$(document).on("submit", "#update-profile-photo", function(e){

    e.preventDefault();

    SweetAlert.fire({
        icon: 'question',
        title: 'Are you sure?',
        text: "This will update your profile picture.",
        showCancelButton: true,
        confirmButtonColor: '#160e45',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Confirm!'
    }).then((result) => {
        if (result.value) {
            $.ajax({
                type: 'POST',
                url: '/update/profile-photo',
                data: new FormData(this),
                dataType: 'json',
                contentType: false,
                cache: false,
                processData:false,
                beforeSend:function(){
                    Swal.fire({
                        position: 'center',
                        icon: 'info',
                        title: 'Updating...',
                        showConfirmButton: false
                    })
                },
                success:function(response){
                    if (response.Error == 0){
                        SweetAlert.fire({
                            icon: 'success',
                            title: 'Done',
                            text: response.Message,
                            confirmButtonColor: "#3a57e8"
                        }).then(function(){ 
                            location.reload();
                            });
                    }
                }
            });
        }
    })
});

//NOTIFICATION

$(document).on("click", '#view-notif', function(){

    $("#notif-count").text(0);
    
    $.ajax({
        type: 'POST',
        url: '/update/notify',
        data: { read:true },
        dataType: 'json',
        cache: false,
        success: function(response)
        {

        }
    })

});

//CHANGE YEAR

$(document).on('change', "#change-year", function(e){
    var year = $('#change-year').val();
    $.ajax({
        type: 'POST',
        url: '/search/year',
        data: { year },
        dataType: 'json',
        success: function()
        {
            location.reload();
        }
    })
});

//SMS CONFIGURATION

$(document).on('submit', "#sms-configuration", function(e){
    e.preventDefault();
    $.ajax({
        type: 'POST',
        url: '/update/sms-configuration',
        data: new FormData(this),
        dataType: 'json',
        contentType: false,
        cache: false,
        processData:false,
        beforeSend:function(){
            Swal.fire({
                position: 'center',
                icon: 'info',
                title: 'Updating...',
                showConfirmButton: false
            })
        },
        success: function(response)
        {
            if(response.Error == 0) {
                SweetAlert.fire({
                    icon: 'success',
                    title: 'Done',
                    text: response.Message,
                    confirmButtonColor: "#3a57e8"
                }).then(function(){ 
                    location.reload();
                    });
            }
        }
    })
});

//SEACH ACCOUNTS:

$(document).on('keyup', "#search-barangay-account", function(e){

    var search_account = $('#search-barangay-account').val();

    $.ajax({
        method: 'POST',
        url: '/search/account',
        data: {search_account},
        dataType: 'text',
        success: function(response)
        {
            $('#search-barangay-result').html(response);
        }
    })
});

$(document).on('keyup', "#search-user-account", function(e){

    var search_account = $('#search-user-account').val();

    $.ajax({
        method: 'POST',
        url: '/search/account',
        data: {search_account},
        dataType: 'text',
        success: function(response)
        {
            $('#search-user-result').html(response);
        }
    })
});

$(document).on('click', "#select-barangay-account", function(e){

    var search_account = $('#barangay-user-account').val();

    $.ajax({
        method: 'POST',
        url: '/search/barangay-users',
        data: {search_account},
        dataType: 'text',
        success: function(response)
        {
            $('#search-barangay-result').html(response);
        }
    })
});

$(document).on('click', "#select-barangay-user-account", function(e){

    var search_account = $('#barangay-user-account').val();

    $.ajax({
        method: 'POST',
        url: '/search/barangay-users',
        data: {search_account},
        dataType: 'text',
        success: function(response)
        {
            $('#search-user-result').html(response);
        }
    })
});

$(document).on('change', "#barangay-report", function(e){

    var search_report = $('#barangay-report').val();
    var type = $("#type").val();

    $.ajax({
        method: 'POST',
        url: '/search/barangay-report',
        data: {search_report, type},
        dataType: 'text',
        success: function(response)
        {
            $('#barangay-report-result').html(response);
        }
    })
});

//TYPES

$(document).on("click", '#create-type', function(){
    $('#create-type-modal').modal('show');
});

$(document).on('submit', "#create-type", function(e){
    e.preventDefault();
    $.ajax({
        type: 'POST',
        url: '/create/type',
        data: new FormData(this),
        dataType: 'json',
        contentType: false,
        cache: false,
        processData:false,
        beforeSend:function(){
            $('#processing-type').show(50);
            $('#processing-type').html('Processing...');
        },
        success: function(response)
        {
            if(response.Error == 0) {
                $('#processing-type').hide(50);
                SweetAlert.fire({
                    icon: 'success',
                    title: 'Done',
                    text: response.Message,
                    confirmButtonColor: "#3a57e8"
                }).then(function(){ 
                    location.reload();
                    });
            }
        }
    })
});

$(document).on("click", '#edit-type', function(){

    var typeid = $(this).parents('tr').find('td[typeid]').attr("typeid");
    var type = $(this).parents('tr').find('td[type]').attr("type");
    var subtype = $(this).parents('tr').find('td[subtype]').attr("subtype");

    $("#edit-maintype option").filter((i, e) => {
        return e.innerHTML.indexOf(type) > -1;
    }).val();

    $('#edit-typeid').val(typeid);
    $('#edit-maintype').val(type);
    $('#edit-subtype').val(subtype);
   
    $('#edit-type-modal').modal('show');
});

$(document).on('submit', "#update-type", function(e){
    e.preventDefault();
    $.ajax({
        type: 'POST',
        url: '/update/type',
        data: new FormData(this),
        dataType: 'json',
        contentType: false,
        cache: false,
        processData:false,
        beforeSend:function(){
            $('#edit-processing-type').show(50);
            $('#edit-processing-type').html('Processing...');
        },
        success: function(response)
        {
            if(response.Error == 0) {
                $('#edit-processing-type').hide(50);
                SweetAlert.fire({
                    icon: 'success',
                    title: 'Done',
                    text: response.Message,
                    confirmButtonColor: "#3a57e8"
                }).then(function(){ 
                    location.reload();
                    });
            }
        }
    })
});

$(document).on("click", "#delete-type", function(e){

    var typeid = $(this).parents('tr').find('td[typeid]').attr("typeid");

    SweetAlert.fire({
        icon: 'question',
        title: 'Are you sure?',
        text: "This will delete the type permanently.",
        showCancelButton: true,
        confirmButtonColor: '#160e45',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Delete!'
    }).then((result) => {
        if (result.value) {
            $.ajax({
                type: 'POST',
                url: '/delete/type',
                data: {typeid},
                dataType: 'json',
                cache: false,
                beforeSend:function(){
                    Swal.fire({
                        position: 'center',
                        icon: 'info',
                        title: 'Deleting...',
                        showConfirmButton: false
                    })
                },
                success:function(response){
                    if (response.Error == 0){
                        SweetAlert.fire({
                            icon: 'success',
                            title: 'Done',
                            text: response.Message,
                            confirmButtonColor: "#3a57e8"
                        }).then(function(){ 
                            location.reload();
                            });
                    }
                }
            });
        }
    })
});