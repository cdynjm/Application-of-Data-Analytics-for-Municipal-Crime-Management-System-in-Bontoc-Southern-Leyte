
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center py-4">
    <div class="d-block mb-4 mb-md-0">
        
        <h2 class="h4">SMS Configuration</h2>
    </div>
</div>

<div class="row">   
    <div class="col-12">
        <div class="card card-body">
                <form action="" id="sms-configuration">
                <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-8 d-flex align-items-center">
                            <h6 class="mb-3">Pushbullet Account Settings (SMS)</h6>
                        </div>
                        <div class="col-md-12">
                            <p class="text-wrap text-justify text-sm">Pushbullet's API enables developers to build on the Pushbullet infrastructure. Our goal is to provide a full API that enables anything to tap into the Pushbullet network.
                            The Pushbullet API lets you send/receive pushes and do everything else the official Pushbullet clients can do. To access the API you'll need an access token so the server knows who you are. You can get one from your <a href="https://www.pushbullet.com/" target="_blank" class="text-info text-decoration-underline">Account Settings</a> page.
                            </p>
                        </div>

                        <?php $__currentLoopData = $smstoken; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="mb-3 col-md-12">
                                <label class="form-label">URL</label>
                                <input type="text" name="url" class="form-control text-info text-decoration-underline" value='<?php echo e($st->url); ?>'>
                            </div>
                            <div class="mb-3 col-md-6">
                                <label class="form-label">Access Token</label>
                                <input type="text" name="access_token" class="form-control fw-bold" value='<?php echo e($st->access_token); ?>'>
                            </div>
                            <div class="mb-3 col-md-6">
                                <label class="form-label">Mobile Identity</label>
                                <input type="text" name="mobile_identity" class="form-control fw-bold" value='<?php echo e($st->mobile_identity); ?>'>
                            </div>

                            <div class="mb-3 col-md-12">
                                <button class="btn btn-primary mt-2">Update</button>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </form>
            </div>
        </div>
    
</div><?php /**PATH /home/ccsit/public_html/student/mcms/resources/views/sms-configuration.blade.php ENDPATH**/ ?>