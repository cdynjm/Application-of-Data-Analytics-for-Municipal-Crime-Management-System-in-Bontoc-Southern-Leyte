<nav id="sidebarMenu" class="sidebar d-lg-block bg-gray-800 text-white collapse" data-simplebar style="box-shadow: 2px 2px 10px gray;">
  <div class="sidebar-inner px-2 pt-3">
    <div class="user-card d-flex d-md-none align-items-center justify-content-between justify-content-md-center pb-4">
      <div class="d-flex align-items-center">
        <div class="avatar-lg me-4">
          <img src="/assets/img/team/profile-picture-3.jpg" class="card-img-top rounded-circle border-white"
            alt="Bonnie Green">
        </div>
        <div class="d-block">
          <h2 class="h5 mb-3">Hi, Jane</h2>
          <a href="/login" class="btn btn-secondary btn-sm d-inline-flex align-items-center">
            <svg class="icon icon-xxs me-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path>
            </svg>
            Sign Out
          </a>
        </div>
      </div>
      <div class="collapse-close d-md-none">
        <a href="#sidebarMenu" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu"
          aria-expanded="true" aria-label="Toggle navigation">
          <svg class="icon icon-xs" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd"
              d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
              clip-rule="evenodd"></path>
          </svg>
        </a>
      </div>
    </div>
    <ul class="nav flex-column pt-3 pt-md-0">
      <li class="nav-item">
        <a href="/dashboard" class="nav-link d-flex align-items-center">
          <span class="sidebar-icon me-3">
            <img src="https://scontent.fceb1-1.fna.fbcdn.net/v/t39.30808-6/291320225_111535494947478_5971878344979852442_n.jpg?_nc_cat=108&ccb=1-7&_nc_sid=1b51e3&_nc_eui2=AeFKH8OcboINwOslOvWDkUuL8Cq1B_PPbx7wKrUH889vHnEcRhH3HgcdPFI07YAufgPyqYg-01CymLp3S7sQ88q9&_nc_ohc=6MUgOfHeTNEAX8zM9e_&_nc_ht=scontent.fceb1-1.fna&oh=00_AfBpkHwfMzgwu9w9RjWYVKTNiNjDP5uipks1G7eKs_Prow&oe=650DA291" height="60" width="60" alt="Volt Logo" style="border-radius: 50px">
          </span>
          <span class="mt-1 ms-1 sidebar-text fw-bolder fs-4">
            MCAMS
            <p style="font-size: 10px;">Municipal Crime & <br> Accident MS</p>
          </span>
        </a>
      </li>

      <li role="separator" class="dropdown-divider mb-3 border-gray-700"></li>

      <li class="nav-item <?php echo e(Request::segment(1) == 'dashboard' ? 'active' : ''); ?>">
        <a href="/dashboard" class="nav-link">
          <span class="sidebar-icon"> <svg class="icon icon-xs me-2" fill="currentColor" viewBox="0 0 20 20"
              xmlns="http://www.w3.org/2000/svg">
              <path d="M2 10a8 8 0 018-8v8h8a8 8 0 11-16 0z"></path>
              <path d="M12 2.252A8.014 8.014 0 0117.748 8H12V2.252z"></path>
            </svg></span></span>
          <span class="sidebar-text" style="font-size: 13px;">Dashboard</span>
        </a>
      </li>

      <li class="nav-item <?php echo e(Request::segment(1) == 'profile' ? 'active' : ''); ?>">
        <a href="/profile" class="nav-link">
          <span class="sidebar-icon"> <svg class="icon icon-xs me-2" xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16">
  <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z"/>
  <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z"/>
</svg></span></span>
          <span class="sidebar-text" style="font-size: 13px;">Profile</span>
        </a>
      </li>

      <li class="nav-item <?php echo e(Request::segment(1) == 'users' ? 'active' : ''); ?>">
        <a href="/users" class="nav-link">
          <span class="sidebar-icon"> <svg class="icon icon-xs me-2" xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-people-fill" viewBox="0 0 16 16">
  <path d="M7 14s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1H7Zm4-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6Zm-5.784 6A2.238 2.238 0 0 1 5 13c0-1.355.68-2.75 1.936-3.72A6.325 6.325 0 0 0 5 9c-4 0-5 3-5 4s1 1 1 1h4.216ZM4.5 8a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z"/>
</svg></span></span>
          <span class="sidebar-text" style="font-size: 13px;">User Management</span>
        </a>
      </li>
          
      <li class="nav-item <?php echo e(Request::segment(1) == 'transactions' ? 'active' : ''); ?>">
        <a href="/transactions" class="nav-link">
          <span class="sidebar-icon"><svg class="icon icon-xs me-2" fill="currentColor" viewBox="0 0 20 20"
              xmlns="http://www.w3.org/2000/svg">
              <path d="M4 4a2 2 0 00-2 2v1h16V6a2 2 0 00-2-2H4z"></path>
              <path fill-rule="evenodd"
                d="M18 9H2v5a2 2 0 002 2h12a2 2 0 002-2V9zM4 13a1 1 0 011-1h1a1 1 0 110 2H5a1 1 0 01-1-1zm5-1a1 1 0 100 2h1a1 1 0 100-2H9z"
                clip-rule="evenodd"></path>
            </svg></span>
          <span class="sidebar-text" style="font-size: 13px;">Transactions</span>
        </a>
      </li>
  
      <li class="nav-item">
        <span
          class="nav-link <?php echo e(Request::segment(1) !== 'bootstrap-tables' ? 'collapsed' : ''); ?> d-flex justify-content-between align-items-center"
          data-bs-toggle="collapse" data-bs-target="#submenu-app">
          <span>
            <span class="sidebar-icon"><svg class="icon icon-xs me-2" fill="currentColor" viewBox="0 0 20 20"
                xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd"
                  d="M5 4a3 3 0 00-3 3v6a3 3 0 003 3h10a3 3 0 003-3V7a3 3 0 00-3-3H5zm-1 9v-1h5v2H5a1 1 0 01-1-1zm7 1h4a1 1 0 001-1v-1h-5v2zm0-4h5V8h-5v2zM9 8H4v2h5V8z"
                  clip-rule="evenodd"></path>
              </svg></span>
            <span class="sidebar-text" style="font-size: 13px;">Tables</span>
          </span>
          <span class="link-arrow"><svg class="icon icon-sm" fill="currentColor" viewBox="0 0 20 20"
              xmlns="http://www.w3.org/2000/svg">
              <path fill-rule="evenodd"
                d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"
                clip-rule="evenodd"></path>
            </svg></span>
        </span>
        <div class="multi-level collapse <?php echo e(Request::segment(1) == 'bootstrap-tables' ? 'show' : ''); ?>" role="list"
          id="submenu-app" aria-expanded="false">
          <ul class="flex-column nav">
            <li class="nav-item <?php echo e(Request::segment(1) == 'bootstrap-tables' ? 'active' : ''); ?>">
              <a class="nav-link" href="/bootstrap-tables">
                <span class="sidebar-text" style="font-size: 13px;">Bootstrap Tables</span>
              </a>
            </li>
          </ul>
        </div>
      </li>
      <li class="nav-item">
        <span class="nav-link collapsed d-flex justify-content-between align-items-center" data-bs-toggle="collapse"
          data-bs-target="#submenu-pages">
          <span>
            <span class="sidebar-icon"><svg class="icon icon-xs me-2" fill="currentColor" viewBox="0 0 20 20"
                xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd"
                  d="M2 5a2 2 0 012-2h8a2 2 0 012 2v10a2 2 0 002 2H4a2 2 0 01-2-2V5zm3 1h6v4H5V6zm6 6H5v2h6v-2z"
                  clip-rule="evenodd"></path>
                <path d="M15 7h1a2 2 0 012 2v5.5a1.5 1.5 0 01-3 0V7z"></path>
              </svg></span>
            <span class="sidebar-text" style="font-size: 13px;">Page examples</span>
          </span>
          <span class="link-arrow"><svg class="icon icon-sm" fill="currentColor" viewBox="0 0 20 20"
              xmlns="http://www.w3.org/2000/svg">
              <path fill-rule="evenodd"
                d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"
                clip-rule="evenodd"></path>
            </svg></span>
        </span>
        <div class="multi-level collapse" role="list" id="submenu-pages" aria-expanded="false">
          <ul class="flex-column nav">
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('profile-example')); ?>">
                <span class="sidebar-text" style="font-size: 13px;">Profile</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('login-example')); ?>">
                <span class="sidebar-text" style="font-size: 13px;">Sign In</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('register-example')); ?>">
                <span class="sidebar-text" style="font-size: 13px;">Sign Up</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('forgot-password-example')); ?>">
                <span class="sidebar-text" style="font-size: 13px;">Forgot password</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="/reset-password-example">
                <span class="sidebar-text" style="font-size: 13px;">Reset password</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="/lock">
                <span class="sidebar-text" style="font-size: 13px;">Lock</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="/404">
                <span class="sidebar-text" style="font-size: 13px;">404 Not Found</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="/500">
                <span class="sidebar-text" style="font-size: 13px;">500 Not Found</span>
              </a>
            </li>
          </ul>
        </div>
      </li>
      <li class="nav-item">
        <span class="nav-link collapsed d-flex justify-content-between align-items-center" data-bs-toggle="collapse"
          data-bs-target="#submenu-components">
          <span>
            <span class="sidebar-icon"><svg class="icon icon-xs me-2" fill="currentColor" viewBox="0 0 20 20"
                xmlns="http://www.w3.org/2000/svg">
                <path d="M4 3a2 2 0 100 4h12a2 2 0 100-4H4z"></path>
                <path fill-rule="evenodd"
                  d="M3 8h14v7a2 2 0 01-2 2H5a2 2 0 01-2-2V8zm5 3a1 1 0 011-1h2a1 1 0 110 2H9a1 1 0 01-1-1z"
                  clip-rule="evenodd"></path>
              </svg></span>
            <span class="sidebar-text" style="font-size: 13px;">Components</span>
          </span>
          <span class="link-arrow"><svg class="icon icon-sm" fill="currentColor" viewBox="0 0 20 20"
              xmlns="http://www.w3.org/2000/svg">
              <path fill-rule="evenodd"
                d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"
                clip-rule="evenodd"></path>
            </svg></span>
        </span>
        <div
          class="multi-level collapse <?php echo e(Request::segment(1) == 'buttons' || Request::segment(1) == 'notifications' || Request::segment(1) == 'forms' || Request::segment(1) == 'modals' || Request::segment(1) == 'typography' ? 'show' : ''); ?>"
          role="list" id="submenu-components" aria-expanded="false">
          <ul class="flex-column nav">
            <li class="nav-item <?php echo e(Request::segment(1) == 'buttons' ? 'active' : ''); ?>">
              <a class="nav-link" href="/buttons">
                <span class="sidebar-text">Buttons</span>
              </a>
            </li>
            <li class="nav-item <?php echo e(Request::segment(1) == 'notifications' ? 'active' : ''); ?>">
              <a class="nav-link" href="/notifications">
                <span class="sidebar-text">Notifications</span>
              </a>
            </li>
            <li class="nav-item <?php echo e(Request::segment(1) == 'forms' ? 'active' : ''); ?>">
              <a class="nav-link" href="/forms">
                <span class="sidebar-text">Forms</span>
              </a>
            </li>
            <li class="nav-item <?php echo e(Request::segment(1) == 'modals' ? 'active' : ''); ?>">
              <a class="nav-link" href="/modals">
                <span class="sidebar-text">Modals</span>
              </a>
            </li>
            <li class="nav-item <?php echo e(Request::segment(1) == 'typography' ? 'active' : ''); ?>">
              <a class="nav-link" href="/typography">
                <span class="sidebar-text">Typography</span>
              </a>
            </li>
          </ul>
        </div>
      </li>
    </ul>
  </div>
</nav><?php /**PATH D:\Documents\Web Projects\volt-laravel-dashboard-master\resources\views/layouts/sidenav.blade.php ENDPATH**/ ?>