<?php echo e($slot); ?>

<?php /**PATH D:\Documents\Web Projects\Municipal-Crime-and-Accident-MS\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>