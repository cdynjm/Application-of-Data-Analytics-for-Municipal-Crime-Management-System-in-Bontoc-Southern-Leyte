<!-- The Modal -->
<div class="modal fade" id="update-profile-photo-modal" aria-hidden="true" style="display: none;">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">New Profile Photo</h5>
                <button type="button" class="btn-close bg-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
                <div class="modal-body">  
                    <div class="alert alert-info" style="display: none;" id='processing-photo'></div>
                    <form id="update-profile-photo" action="#" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        
                        <input type="file" name="profilePhoto" class="form-control mb-2" onchange="viewProfilePhoto(this)" required>
                        
                        <center>
                            <img src="<?php echo e(asset('storage/icon/profile-placeholder.jpg')); ?>" alt="" class="mt-4 img-fluid" id="profile-photo" style="border-radius: 100px; width: 200px; height: auto">
                        </center>

                        <button class="btn btn-primary mt-2">Update</button>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div> <?php /**PATH D:\Documents\Web Projects\Municipal-Crime-and-Accident-MS\resources\views/components/modals/update-profile-photo-modal.blade.php ENDPATH**/ ?>