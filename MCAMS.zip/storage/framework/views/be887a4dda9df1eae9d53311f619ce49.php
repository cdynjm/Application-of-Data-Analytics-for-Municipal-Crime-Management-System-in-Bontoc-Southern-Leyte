<!-- The Modal -->
<div class="modal fade" id="edit-report-modal" aria-hidden="true" style="display: none;">
    <div class="modal-dialog ">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Report</h5>
                <button type="button" class="btn-close bg-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
                <div class="modal-body">  
                    <div class="alert alert-info" style="display: none;" id='edit-processing-report'></div>
                    <form id="update-report" action="#" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" class="form-control" name="reportid" id="edit-reportid">
                        <div class="row">
                            <div class="col-md-12">

                                <label for="">Description</label>
                                <textarea class="form-control mb-2" name="description" id="edit-description" cols="30" rows="5"></textarea>

                                <label for="">Type</label>
                                <select name="type" id="edit-type" class="form-select mb-2" required>
                                    <option value="">Select Type</option>
                                    <option value="Accident">Accident</option>
                                    <option value="Crime/Scandal">Crime/Scandal</option>
                                </select>

                                <div class="edit-accident" style="display: none;">
                                    <label for="">Accident Type</label>
                                    <select name="accident" id="edit-accident-select"  class="form-select mb-2">
                                        <option value="">Select Accident Type</option>
                                        <?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($ty->type == 1): ?>
                                                <option value="<?php echo e($ty->id); ?>"><?php echo e($ty->subtype); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="edit-crime" style="display: none;">
                                    <label for="">Crime/Scandal Type</label>
                                    <select name="crime" id="edit-crime-select" class="form-select mb-2">
                                        <option value="">Select Crime Type</option>
                                        <?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($ty->type == 2): ?>
                                                <option value="<?php echo e($ty->id); ?>"><?php echo e($ty->subtype); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <label for="">Barangay</label>
                                <select name="location" id="edit-location" class="form-select mb-2" required>
                                    <option value="">Select...</option>
                                    <?php $__currentLoopData = $barangay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brgy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($brgy->id); ?>"><?php echo e($brgy->brgy); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                                <label for="">Purok/Street/Zone</label>
                                <input type="text" class="form-control mb-2" name="zone" placeholder="Pls Specify..." id="edit-zone" required>
                            </div>
                        </div>
                        <button class="btn btn-primary mt-2">Update</button>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div> <?php /**PATH /home/ccsit/public_html/student/mcms/resources/views/components/modals/edit/edit-report-modal.blade.php ENDPATH**/ ?>