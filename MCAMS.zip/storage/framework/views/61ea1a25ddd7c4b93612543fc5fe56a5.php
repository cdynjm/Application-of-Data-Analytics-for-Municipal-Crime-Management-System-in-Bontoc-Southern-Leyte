<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center py-4">
    <div class="d-block mb-4 mb-md-0">
        
        <h2 class="h4">Users List</h2>
    </div>
    <div class="btn-toolbar mb-2 mb-md-0">
        <a href="#" class="btn btn-sm btn-gray-800 d-inline-flex align-items-center" id="create-barangay-account">
            <svg class="icon icon-xs me-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6">
                </path>
            </svg>
            Barangay Account
        </a>
    </div>
</div>
<div class="table-settings mb-4">
    <div class="row justify-content-between align-items-center">
        <div class="col-9 col-lg-8 d-md-flex">
            <div class="input-group me-2 me-lg-3 fmxw-300">
                <span class="input-group-text">
                    <svg class="icon icon-xs" x-description="Heroicon name: solid/search"
                        xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                        <path fill-rule="evenodd"
                            d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z"
                            clip-rule="evenodd"></path>
                    </svg>
                </span>
                <input type="text" class="form-control" placeholder="Search users">
            </div>
            <select class="form-select fmxw-200 d-md-inline" id="change-type" aria-label="Message select example 2">
                <option <?php if(Session::get('type') == 2): ?> selected <?php endif; ?> value="2">Barangay Accounts</option>
                <option <?php if(Session::get('type') == 3): ?> selected <?php endif; ?> value="3">User Accounts</option>
            </select>
        </div>
        <div class="col-3 col-lg-4 d-flex justify-content-end">
            <div class="btn-group">
                <div class="dropdown me-1">
                    <button class="btn btn-link text-dark dropdown-toggle dropdown-toggle-split m-0 p-1"
                        data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <svg class="icon icon-sm" fill="currentColor" viewBox="0 0 20 20"
                            xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M5 4a1 1 0 00-2 0v7.268a2 2 0 000 3.464V16a1 1 0 102 0v-1.268a2 2 0 000-3.464V4zM11 4a1 1 0 10-2 0v1.268a2 2 0 000 3.464V16a1 1 0 102 0V8.732a2 2 0 000-3.464V4zM16 3a1 1 0 011 1v7.268a2 2 0 010 3.464V16a1 1 0 11-2 0v-1.268a2 2 0 010-3.464V4a1 1 0 011-1z">
                            </path>
                        </svg>
                        <span class="visually-hidden">Toggle Dropdown</span>
                    </button>
                    <div class="dropdown-menu dropdown-menu-end pb-0">
                        <span class="small ps-3 fw-bold text-dark">Show</span>
                        <a class="dropdown-item d-flex align-items-center fw-bold" href="#">10 <svg
                                class="icon icon-xxs ms-auto" fill="currentColor" viewBox="0 0 20 20"
                                xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd"
                                    d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                                    clip-rule="evenodd"></path>
                            </svg></a>
                        <a class="dropdown-item fw-bold" href="#">20</a>
                        <a class="dropdown-item fw-bold rounded-bottom" href="#">30</a>
                    </div>
                </div>
                <div class="dropdown">
                    <button class="btn btn-link text-dark dropdown-toggle dropdown-toggle-split m-0 p-1"
                        data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <svg class="icon icon-sm" fill="currentColor" viewBox="0 0 20 20"
                            xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd"
                                d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z"
                                clip-rule="evenodd"></path>
                        </svg>
                        <span class="visually-hidden">Toggle Dropdown</span>
                    </button>
                    <div class="dropdown-menu dropdown-menu-xs dropdown-menu-end pb-0">
                        <span class="small ps-3 fw-bold text-dark">Show</span>
                        <a class="dropdown-item d-flex align-items-center fw-bold" href="#">10 <svg
                                class="icon icon-xxs ms-auto" fill="currentColor" viewBox="0 0 20 20"
                                xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd"
                                    d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                                    clip-rule="evenodd"></path>
                            </svg></a>
                        <a class="dropdown-item fw-bold" href="#">20</a>
                        <a class="dropdown-item fw-bold rounded-bottom" href="#">30</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php if(Session::get('type') == 2): ?>
<div class="card card-body shadow border-0 table-wrapper table-responsive">
    
    <table class="table table-centered table-nowrap mb-0 rounded mt-4">
        <thead class="thead-light">
            <tr>
                <th class="border-bottom">No.</th>
                <th class="border-bottom">Name</th>
                <th class="border-bottom">Email</th>
                <th class="border-bottom">Role</th>
                <th class="border-bottom">Date Created</th>
                <th class="border-bottom">Barangay</th>
                <th class="border-bottom">Phone</th>
                <th class="border-bottom">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $cnt = 1; ?>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($user->type == 2): ?>
            <tr>
                <td userid='<?php echo e($user->id); ?>' hidden></td>
                <td firstname='<?php echo e($user->first_name); ?>' hidden></td>
                <td lastname='<?php echo e($user->last_name); ?>' hidden></td>
                <td email='<?php echo e($user->email); ?>' hidden></td>
                <td contactnumber='<?php echo e($user->number); ?>' hidden></td>
                <td address='<?php echo e($user->address); ?>' hidden></td>
                <td>
                    <?php echo e($cnt); ?>

                </td>
                <td>
                    <?php echo e($user->last_name); ?>, <?php echo e($user->first_name); ?>

                </td>
                <td><span class="fw-normal"><?php echo e($user->email); ?></span></td>
                <td><span class="fw-normal"><?php if($user->type == 2): ?> <?php echo e('Barangay Admin'); ?> <?php endif; ?></span></td>
                <td><span class="fw-normal d-flex align-items-center"><?php echo e(date('M d Y', strtotime($user->created_at))); ?></span></td>
                <td><span class="fw-bolder "><?php echo e($user->Barangay->brgy); ?></span></td>
                <td><span class="fw-normal"><?php echo e($user->number); ?></span></td>
                <td>
                    <div class="btn-group">
                        <button class="btn btn-link text-dark dropdown-toggle dropdown-toggle-split m-0 p-0"
                            data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <svg class="icon icon-xs" fill="currentColor" viewBox="0 0 20 20"
                                xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M6 10a2 2 0 11-4 0 2 2 0 014 0zM12 10a2 2 0 11-4 0 2 2 0 014 0zM16 12a2 2 0 100-4 2 2 0 000 4z">
                                </path>
                            </svg>
                            <span class="visually-hidden">Toggle Dropdown</span>
                        </button>
                        <div class="dropdown-menu dashboard-dropdown dropdown-menu-start mt-2 py-1">
                            <a class="dropdown-item d-flex align-items-center" href="#" id="edit-barangay-account">
                                <span class="fas fa-user-shield me-2"></span>
                                Edit
                            </a>
                            <a class="dropdown-item text-danger d-flex align-items-center" href="#" id="delete-barangay-account">
                                <span class="fas fa-user-times me-2"></span>
                                Delete
                            </a>
                        </div>
                    </div>
                </td>
            </tr>
            <?php $cnt+=1; ?>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php endif; ?>
<?php if(Session::get('type') == 3): ?>
<div class="card card-body shadow border-0 table-wrapper table-responsive">
    <div class="d-flex mb-3">
        <select class="form-select fmxw-200" aria-label="Message select example">
            <option selected>Select Barangay...</option>
            <?php $__currentLoopData = $barangay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brgy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($brgy->id); ?>"><?php echo e($brgy->brgy); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <button class="btn btn-sm px-3 btn-secondary ms-3">Apply</button>
    </div>
    <table class="table table-centered table-nowrap mb-0 rounded">
        <thead class="thead-light">
            <tr>
                <th class="border-bottom">No.</th>
                <th class="border-bottom">Name</th>
                <th class="border-bottom">Email</th>
                <th class="border-bottom">Role</th>
                <th class="border-bottom">Date Created</th>
                <th class="border-bottom">Barangay</th>
                <th class="border-bottom">Phone</th>
                <th class="border-bottom">Status</th>
                <th class="border-bottom">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $cnt = 1; ?>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($user->type == 3): ?>
            <tr>
                <td userid='<?php echo e($user->id); ?>' hidden></td>
                <td firstname='<?php echo e($user->first_name); ?>' hidden></td>
                <td lastname='<?php echo e($user->last_name); ?>' hidden></td>
                <td email='<?php echo e($user->email); ?>' hidden></td>
                <td contactnumber='<?php echo e($user->number); ?>' hidden></td>
                <td address='<?php echo e($user->address); ?>' hidden></td>
                <td>
                    <?php echo e($cnt); ?>

                </td>
                <td>
                    <?php echo e($user->last_name); ?>, <?php echo e($user->first_name); ?>

                </td>
                <td><span class="fw-normal"><?php echo e($user->email); ?></span></td>
                <td><span class="fw-normal"><?php if($user->type == 3): ?> <?php echo e('User'); ?> <?php endif; ?></span></td>
                <td><span class="fw-normal d-flex align-items-center"><?php echo e(date('M d Y', strtotime($user->created_at))); ?></span></td>
                <td><span class="fw-bolder "><?php echo e($user->Barangay->brgy); ?></span></td>
                <td><span class="fw-normal"><?php echo e($user->number); ?></span></td>
                <td>
                    <?php if($user->status == 1): ?><span class="fw-normal text-danger"><?php echo e('Pending'); ?></span><?php endif; ?>
                    <?php if($user->status == 0): ?><span class="fw-normal text-success"><?php echo e('Verified'); ?></span><?php endif; ?>
                </td>
                <td>
                    <div class="btn-group">
                        <button class="btn btn-link text-dark dropdown-toggle dropdown-toggle-split m-0 p-0"
                            data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <svg class="icon icon-xs" fill="currentColor" viewBox="0 0 20 20"
                                xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M6 10a2 2 0 11-4 0 2 2 0 014 0zM12 10a2 2 0 11-4 0 2 2 0 014 0zM16 12a2 2 0 100-4 2 2 0 000 4z">
                                </path>
                            </svg>
                            <span class="visually-hidden">Toggle Dropdown</span>
                        </button>
                        <div class="dropdown-menu dashboard-dropdown dropdown-menu-start mt-2 py-1">
                            <a class="dropdown-item d-flex align-items-center" href="#" id="edit-user-account">
                                <span class="fas fa-user-shield me-2"></span>
                                Edit
                            </a>
                            <?php if($user->status == 1): ?>
                            <a class="dropdown-item d-flex text-success align-items-center" href="#" id="verify-user-account">
                                <span class="fas fa-user-check me-2"></span>
                                Verify
                            </a>
                            <?php endif; ?>
                            <a class="dropdown-item text-danger d-flex align-items-center" href="#" id="delete-user-account">
                                <span class="fas fa-user-times me-2"></span>
                                Delete
                            </a>
                        </div>
                    </div>
                </td>
            </tr>
            <?php $cnt+=1; ?>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php endif; ?>
<?php echo $__env->make('components.modals.edit.edit-user-account-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components.modals.edit.edit-barangay-account-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components.modals.barangay-account-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Documents\Web Projects\volt-laravel-dashboard-master\resources\views/livewire/users.blade.php ENDPATH**/ ?>