<?php

namespace App\Http\Livewire\Components;

use Livewire\Component;

class Buttons extends Component
{
    public function render()
    {
        return view('components.buttons');
    }
}
